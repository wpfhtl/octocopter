#ifndef QRK_DELAY_H
#define QRK_DELAY_H

/*!
  \file
  \brief �ҋ@

  \author Satofumi KAMIMURA

  $Id: delay.h 772 2009-05-05 06:57:57Z satofumi $
*/

namespace qrk
{
  /*!
    \brief �ҋ@

    \param[in] delay �ҋ@���� [msec]
  */
  extern void delay(int msec);
}

#endif /* !QRK_DELAY_H */
